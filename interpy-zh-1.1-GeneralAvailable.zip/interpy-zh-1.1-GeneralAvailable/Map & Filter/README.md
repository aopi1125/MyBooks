# Map 和 Filter

Map 和 Filter这两个函数能为函数式编程提供便利。我们会通过实例一个一个讨论并理解它们。
